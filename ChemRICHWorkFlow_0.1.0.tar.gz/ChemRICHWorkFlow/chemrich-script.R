## Instruction for running a ChemRICH enrichment analysis for a metabolomics dataset.
## Author Dinesh Kumar Barupal (dinkumar@ucdavis.edu)

## Step 0 # Prepare the input data.

# Step Provide a project name
project_name <- "chemrich_1" # Provide this analysis a name. This will be prefixed to all the exported files.

## STEP 1 Load require R packages.
load.ChemRICH.Packages()

## STEP 2. Load ChemRICH databases
load.ChemRICH.databases()

## STEP 3. Import Study data
data_dict <- readxl::read_xlsx("chemrich_input.xlsx", sheet="data_dict") # Data Dictionary
sample_metadata <- readxl::read_xlsx("chemrich_input.xlsx", sheet="sample_metadata") # Sample metadata
data_matrix <- readxl::read_xlsx("chemrich_input.xlsx", sheet="data_matrix") # Data Matrix

## Step 4. Inspect sample_metadata columns.
colnames(sample_metadata)

grouping_variable <- "TISSUE TYPE"

table(sample_metadata[grouping_variable])

## Step Get compound count by a metabolite category variable.

colnames(data_dict) # First check what variable names you have in the data dictionary

table(data_dict["SUPER PATHWAY"]) # metabolite count by super pathway
table(data_dict["SUB PATHWAY"]) # metabolite count by sub pathway
table(data_dict["PLATFORM"]) # metabolite count by analytical plateform

## Step 5. Find significant metabolites
## If you already have p-value and effect size (fold change or beta coefficient) for your analysis, skip this.
## Provide your results in the data_dict sheet in the chemrich_input.xlsx file. Add two columns - pvalue and fc. FC means fold-change.
## Negative beta values need to be converted to below 1 eg  -2 will become 0.50.

metsig.df <- getSignifMetabolites(grouping_variable)
write.table(metsig.df,paste0(project_name,"_significant_metabolites.txt"), col.names = T, row.names = F, quote = F, sep="\t")

## STEP 5. Prepare Input for ChemRICH
## Compounds having the SMILES codes will be used.
chemrich.input.file <- prepare.chemrich.input()

## Step 6. Get Chemical classes
## If you already have chemical classes. Add a column "ChemicalClass" into the data_dict sheet in the chemrich_input.xlsx file.
chemrich.input.file <- chemrich.getChemicalClass()
write.table(chemrich.input.file,paste0(project_name,"chemrich_input_file_with_clases.txt"), col.names = T, row.names = F, quote = F, sep="\t")


## Step 7. Get significant chemical modules
signif.chemrich.cluster <- chemrich.GetSignificantClasses()

## Step . Visualize enriched modules
export.chemrich.impactPlot(signif.chemrich.cluster)


## Step . Export Interactive ChemRICH plots.
export.chemrich.interactivePlot(signif.chemrich.cluster)

## Export chemical similarity tree
export.chemrich.similarityTree(chemrich.input.file)


## Step . Export Results Tables.
export.chemrich.tables(signif.chemrich.cluster)


## Step . Visualize correlation, KEGG and Chemical Similarity Links within each module
chemrich.getIntegratedNetwork <- function(moduleName,compoundLabel)

# for example
chemrich.getIntegratedNetwork("Adenine Nucleotides", "BIOCHEMICAL NAME")


## Step . Generate Box and whisker plots
chemrich.generateBWplots(moduleNumber,compoundLabel)

