load.ChemRICH.Packages <- function() {
  if (!require("devtools"))
    install.packages('devtools', repos="http://cran.rstudio.com/")
  if (!require("RCurl"))
    install.packages('RCurl', repos="http://cran.rstudio.com/")
  if (!require("pacman"))
    install.packages('pacman', repos="http://cran.rstudio.com/")
  library(devtools)
  library(RCurl)
  library(pacman)
  source('https://bioconductor.org/biocLite.R')
  pacman::p_load(GGally)
  pacman::p_load(DT)
  pacman::p_load(RCurl)
  pacman::p_load(RJSONIO)
  pacman::p_load(ape)
  pacman::p_load(devEMF)
  pacman::p_load(dynamicTreeCut)
  pacman::p_load(extrafont)
  pacman::p_load(ggplot2)
  pacman::p_load(ggpubr)
  pacman::p_load(ggrepel)
  pacman::p_load(grid)
  pacman::p_load(htmlwidgets)
  pacman::p_load(igraph)
  pacman::p_load(magrittr)
  pacman::p_load(network)
  pacman::p_load(officer)
  pacman::p_load(openxlsx)
  pacman::p_load(phytools)
  pacman::p_load(plotly)
  pacman::p_load(plotrix)
  pacman::p_load(rcdk)
  pacman::p_load(readxl)
  pacman::p_load(rvg)
  pacman::p_load(sna)
  pacman::p_load(visNetwork)
  install_github('barupal/chemrich')
  library(ChemRICH)
}

load.ChemRICH.databases <- function() {
  data(cidmesh_smiles_fpbit)  ## CID MESH Mapping
  data(krp) ## CID MESH Mapping
  data(mesh_bit_loc_list) # CID - substructure fingerprint mapping.
  data(treenames.df) # Name of the MESH tree ids.
  data(PubChemMeshCounts) # Count of CIDs and PMIDs in each MeSH Category.
  data(cidsbiosys) # CIDs in the NCBI BioSystems Database
  loadfonts(quiet = T)
  df.mega.mesh$CompoundName <- tolower(df.mega.mesh$CompoundName)
  treenames.df$ClassName <- tolower(treenames.df$ClassName)
}


#identification of significantly different metabolites.
getSignifMetabolites <- function(grouping_variable) {
  # Get the index of samples for both groups.
  ind_1 <- which(sample_metadata[grouping_variable] == unique(sample_metadata[grouping_variable])[[1]][1])+1
  ind_2 <- which(sample_metadata[grouping_variable] == unique(sample_metadata[grouping_variable])[[1]][2])+1
  # Calculation of pvalues
  pvalues <- sapply(1:nrow(data_matrix), function(x) {
    res <-wilcox.test(as.numeric(data_matrix[x,ind_1]),as.numeric(data_matrix[x,ind_2]),paired = F)
    res$p.value
  })
  # Calculation of foldchange
  fcvec <- sapply(1:nrow(data_matrix), function(x) {
    mean(as.numeric(data_matrix[x,ind_1]))/mean(as.numeric(data_matrix[x,ind_2]))
  })
  data.frame(compound=data_dict$CompoundID, pvalue=pvalues, fc = fcvec)
}


prepare.chemrich.input <- function() {
 if(length(which(colnames(data_dict)=="pvalue"))!=0) {

 } else {
    data_dict$pvalue = metsig.df$pvalue
    data_dict$fc = metsig.df$fc
 }
 data_dict.sb <- data_dict[!is.na(data_dict$SMILES),]
 data_dict.sb
}

getCNames <- function(x) {
  if(length(which(treenames.df$MESHTREE==x))>0){
    as.character(treenames.df$ClassName[which(treenames.df$MESHTREE==x)])
  } else {
    x
  }
}

makeSmiles.clean <- function (smi) {
  smi <- gsub("@","",smi)
  smi <- gsub("O-","O",smi)
  smi <- gsub("H[1-4][+]","",smi)
  smi <- gsub("N[+]","N",smi)
  smi <- gsub("/|[\\]","",smi)
  smi <- gsub("[[]C(@{1,}|)H[]]","C",smi)
  smi <- gsub("[[]CH2[]]","C",smi)
  smi
}

arc.cladelabels<-function(tree=NULL,text,node,ln.offset=1.02,
                          lab.offset=1.06,cex=1,orientation="curved",...){
  ## Credit: this function is adopted from http://blog.phytools.org/2017/03/clade-labels-on-circular-fan-tree.html
  obj<-get("last_plot.phylo",envir=.PlotPhyloEnv)
  if(obj$type!="fan") stop("method works only for type=\"fan\"")
  h<-max(sqrt(obj$xx^2+obj$yy^2))
  if(is.null(tree)){
    tree<-list(edge=obj$edge,tip.label=1:obj$Ntip,
               Nnode=obj$Nnode)
    class(tree)<-"phylo"
  }
  d<-getDescendants(tree,node)
  d<-sort(d[d<=Ntip(tree)])
  deg<-atan(obj$yy[d]/obj$xx[d])*180/pi
  ii<-intersect(which(obj$yy[d]>=0),which(obj$xx[d]<0))
  deg[ii]<-180+deg[ii]
  ii<-intersect(which(obj$yy[d]<0),which(obj$xx[d]<0))
  deg[ii]<-180+deg[ii]
  ii<-intersect(which(obj$yy[d]<0),which(obj$xx[d]>=0))
  deg[ii]<-360+deg[ii]
  draw.arc(x=0,y=0,radius=ln.offset*h,deg1=min(deg),deg2=max(deg),lwd = 2)
  if(orientation=="curved")
    arctext(text,radius=lab.offset*h,
            middle=mean(range(deg*pi/180)),cex=cex)
  else if(orientation=="horizontal"){
    x0<-lab.offset*cos(median(deg)*pi/180)*h
    y0<-lab.offset*sin(median(deg)*pi/180)*h
    text(x=x0,y=y0,label=text,
         adj=c(if(x0>=0) 0 else 1,if(y0>=0) 0 else 1),
         offset=0)
  }
}

chemrich.getChemicalClass <- function() {
  if(length(which(colnames(chemrich.input.file)=="ChemicalClass"))!=0) {
    chemrich.input.file$ChemRICHClusters <- chemrich.input.file$ChemicalClass
    return(chemrich.input.file)
  }
  smi.all.fas <- as.character(sapply(chemrich.input.file$SMILES, makeSmiles.clean))
  falabelvec <- sapply(smi.all.fas, function(x) {
    elecount <- table(strsplit(gsub("[0-9]|[)]|[(]|=","",x),"")[[1]])
    falabel <-  ""
    if (length(table(c("c","o")%in%tolower(names(elecount))  )  )==1) {
      if(length(grep("n",x,ignore.case = T))==0) {
        if (elecount['C']>7 & length(grep("CCCC",x))==1 & length(grep("C2",x))!=1  ) { # long carbon but not aromatic or cyclic.
          if (elecount['O']==2) {
            dlen <- length(strsplit(x,"=")[[1]])-2
            falabel <- paste(c("FA",elecount['C'],dlen), collapse="_")
          }
          if(elecount['O']>=3) { ## Put Rules here. How many O and then how many carbon chain. That will make the class.
            if( length(grep("C1",x))==1) {
              if (length(strsplit(x,"C1")[[1]]) ==3 ) {
                dlen <- length(strsplit(x,"=")[[1]])-2
                #falabel <- paste(c("Prostaglandin",elecount['C']), collapse="_")
              } else {
                dlen <- length(strsplit(x,"=")[[1]])-2
                falabel <- paste(c("Epoxy FA",elecount['C']), collapse="_")
              }
            } else {
              if (length(strsplit(x,"=O|CO|OC")[[1]])-2==0){
                dlen <- length(strsplit(x,"=")[[1]])-2
                falabel <- paste(c("OH-FA",elecount['C'],dlen,(elecount['O']-2)), collapse="_")
              } else {
                if (length(strsplit(x,"OC|CO")[[1]]) <3 ) {
                  dlen <- length(strsplit(x,"=")[[1]])-2
                  falabel <- paste(c("O=FA",elecount['C'],dlen), collapse="_")
                }
              }
            }
          }
        }
      }
    }
    falabel
  })

  falabelvec[which(falabelvec=="OH-FA_20_3_2")] <- "DiHETrE"
  falabelvec[which(falabelvec=="OH-FA_20_4_2")] <- "DiHETE"
  falabelvec[which(falabelvec=="O=FA_18_3")] <- "oxo-ODE"
  falabelvec[which(falabelvec=="O=FA_20_5")] <- "oxo-ETE"
  falabelvec[which(falabelvec=="OH-FA_18_1_2")] <- "DiHOME"
  falabelvec[which(falabelvec=="OH-FA_18_1_3")] <- "TriHOME"
  falabelvec[which(falabelvec=="OH-FA_18_2_1")] <- "HODE"
  falabelvec[which(falabelvec=="OH-FA_18_2_2")] <- "DiHODE"
  falabelvec[which(falabelvec=="OH-FA_18_3_1")] <- "HOTrE"
  falabelvec[which(falabelvec=="OH-FA_20_3_1")] <- "HETrE"
  falabelvec[which(falabelvec=="OH-FA_20_4_1")] <- "HETE"
  falabelvec[which(falabelvec=="OH-FA_20_5_1")] <- "HEPE"
  falabelvec[which(falabelvec=="OH-FA_22_5_2")] <- "DiHDPE"
  falabelvec[which(falabelvec=="Epoxy FA_22")] <- "EpDPE"
  falabelvec[which(falabelvec=="Epoxy FA_18")] <- "EpETrE"
  falabelvec[which(falabelvec=="Epoxy FA_20")] <- "EpODE"
  falabelvec[grep("^FA_[0-9]{1,2}_0$", falabelvec)] <- "Saturated FA"
  falabelvec[grep("^FA_[0-9]{1,2}_[1-9]$", falabelvec)] <- "UnSaturated FA"

  cat("Computing sub-structure fingerprint\n")


  fps <- t(sapply(1:nrow(chemrich.input.file), function(x) {
    #print(x)
    xy <- 0
    xy <- as.character(rcdk::get.fingerprint(rcdk::parse.smiles(chemrich.input.file$SMILES[x])[[1]],type="pubchem"))
    xy
  }))

  cid.mesh.df <- data.frame(CID=df.mega.mesh$CID[df.mega.mesh$CID%in%chemrich.input.file$PubChemID],
                            MESHTREE= df.mega.mesh$MESSTREE[df.mega.mesh$CID%in%chemrich.input.file$PubChemID], stringsAsFactors = F)

  ## Covered by MeSH
  inmesh.vec <- rep("No",nrow(chemrich.input.file))
  inmesh.vec[chemrich.input.file$PubChemID%in%cid.mesh.df$CID] <- "Yes"

  ## chemical similarity matrix.
  df1.bitmat <- do.call(rbind,lapply(fps,function(x) as.integer(strsplit(x,"")[[1]][1:881])))
  df1.bitmat.location <- lapply(1:nrow(df1.bitmat), function(x) { which(df1.bitmat[x,]==1) })
  only_b <- sapply(1:length(bitloclist), function(x) {  length(bitloclist[[x]]) })
  bitmeans <- sapply(1:length(bitloclist), function(x) {  median(bitloclist[[x]]) }) # we decided to use median, as some outliers values shall not affect it.
  fpsmeans <- sapply(df1.bitmat.location, function(x){median(x)})

  cat("Obtaining MESH class annotation\n")


  directlabels <- sapply(tolower(chemrich.input.file$`BIOCHEMICAL NAME`), function(x) {
    clabel="Not Found"
    findind <- which(df.mega.mesh$CompoundName==x)
    if(length( findind)>0) {
      classvec <- as.character(df.mega.mesh$MESSTREE[findind])
      classvec <- strsplit(classvec[1],";")[[1]]
      if( length(grep("^D01[.]",classvec)) > 0 ) {
        classvec <- classvec[-grep("^D01[.]|^D03[.]",classvec)]
      }
      clabel <- names(which.max(sapply(classvec,nchar)))
    }
    clabel
  })

  labelvec <- sapply(1:nrow(chemrich.input.file), function(i) {
    clabel <- "Not Found"
    if(falabelvec[i]=="" & inmesh.vec[i]=="No" & directlabels[i]=="Not Found") {
      #if(falabelvec[i]=="") {
      #print(i)
      meanindex <- which(bitmeans < (fpsmeans[i]+5) & bitmeans > (fpsmeans[i]-5))
      bitloclist.sb <- bitloclist[meanindex]
      only_b.sb <- only_b[meanindex]
      overlapvec <- sapply(1:length(bitloclist.sb), function(x) {  length(which(bitloclist.sb[[x]]%in%df1.bitmat.location[[i]]==TRUE)) })
      tmvec <- overlapvec/((length(df1.bitmat.location[[i]])+only_b.sb)-overlapvec)
      if(length(which(tmvec>0.90))>0) {
        if(length(which(tmvec>0.98))>0){
          cidindex <- meanindex[which(tmvec>0.98)]
          if(length(cidindex)==1) {
            clabel <- df.mega.mesh$MESSTREE[cidindex]
          } else {
            clabel.table <- sort(table(unlist(sapply(unique(df.mega.mesh[cidindex[order(tmvec[which(tmvec>0.98)])],"MeSHUID"])[1:10], function(x) {if(!is.na(x)) { strsplit(df.mega.mesh$MESSTREE[which(df.mega.mesh$MeSHUID==x)][1],";")  }}))),decreasing = T)
            clabel.table <- which(clabel.table==clabel.table[1])
            clabel.table.sort <- sort(sapply(names(clabel.table),nchar),decreasing = T)
            clabel.table.sort.max <- which.max(clabel.table.sort)
            if(length(clabel.table.sort.max==1)) {
              clabel <- names(clabel.table.sort.max)
            } else {
              clabel <- sort(names(clabel.table.sort.max))[1]
            }
          }
        } else {
          ## CID_MESH
          cidindex <- meanindex[which(tmvec>0.90)]
          if(length(cidindex)==1) {
            clabel <- df.mega.mesh$MESSTREE[cidindex]
          } else {
            clabel.table <- sort(table(unlist(sapply(unique(df.mega.mesh[cidindex[order(tmvec[which(tmvec>0.90)])],"MeSHUID"])[1:10], function(x) {if(!is.na(x)) { strsplit(df.mega.mesh$MESSTREE[which(df.mega.mesh$MeSHUID==x)][1],";")  }}))),decreasing = T)
            clabel.table <- which(clabel.table==clabel.table[1])
            clabel.table.sort <- sort(sapply(names(clabel.table),nchar),decreasing = T)
            clabel.table.sort.max <- which.max(clabel.table.sort)
            if(length(clabel.table.sort.max==1)) {
              clabel <- names(clabel.table.sort.max)
            } else {
              clabel <- sort(names(clabel.table.sort.max))[1]
            }
          }
        }
      }
    }
    clabel
  })

  finalMesh.df <- cid.mesh.df
  finalMesh.df <- finalMesh.df[which(finalMesh.df$CID%in%chemrich.input.file$PubChemID[which(falabelvec!="")]==FALSE),] ## remove the compounds that are covered by FA labels.
  finalMesh.df <- finalMesh.df[which(finalMesh.df$CID%in%chemrich.input.file$PubChemID[which(directlabels!="Not Found")]==FALSE),] ## remove the compounds that have been covered by the direct label mapping.
  finalMesh.df <- rbind(finalMesh.df,data.frame(CID=chemrich.input.file$PubChemID, MESHTREE=labelvec ))
  finalMesh.df$NewMesh <- finalMesh.df$MESHTREE
  finalMesh.df <- finalMesh.df[which(finalMesh.df$NewMesh!="Not Found"),]
  finalMesh.df <- finalMesh.df[which(finalMesh.df$NewMesh!=""),]
  finalMesh.df <- finalMesh.df[!duplicated(finalMesh.df),]

  # Calculate the chemical similarity and clusters.

  cat("Computing Chemical Similarity\n")

  m <- df1.bitmat
  mat <- m%*%t(m)
  len <- length(m[,1])
  s <- mat.or.vec(len,len)
  for (i in 1:len) {
    for (j in 1:len){
      s[i,j] <- mat[i,j]/(mat[i,i]+mat[j,j]-mat[i,j])
    }
  }
  diag(s) <- 0
  hc <- hclust(as.dist(1-s), method="ward.D2") # ward method provide better clusters.
  clust1 <- cutreeDynamic(hc,distM = as.matrix(1-s),deepSplit =4, minClusterSize = 3)  # can be used to merge cluster, but it is better to keep them as it is. # Clusters are detected using the average linkage hclust.
  chemrich.input.file$ClusterNumber <- clust1
  chemrich.input.file$xlogp <- as.numeric(sapply(chemrich.input.file$SMILES, function(x)  { rcdk::get.xlogp(rcdk::parse.smiles(x)[[1]]) }))

  ## creating the final label data frame.

  finalterm.df <- data.frame(CID=chemrich.input.file$PubChemID, Clabel=falabelvec,stringsAsFactors = F) # first add the fatty acid labels.
  directlabindex <- as.integer(which(directlabels!="Not Found"))[which(as.integer(which(directlabels!="Not Found"))%in%which(finalterm.df$Clabel=="")==TRUE)] ## then add the direct labels found by names matching
  finalterm.df$Clabel[directlabindex] <- as.character(directlabels[directlabindex])

  for (i in 1:nrow(finalterm.df)) { # now add the mesh ids obtained from CouchDB. This will include the mesh annotation calcualted previously.
    if(finalterm.df$Clabel[i]=="" & length(which(finalMesh.df$CID==chemrich.input.file$PubChemID[i]))>0 ) {
      finalterm.df$Clabel[i] <- names(which.max(sapply(unlist(strsplit(finalMesh.df$NewMesh[which(finalMesh.df$CID==chemrich.input.file$PubChemID[i])],";")),nchar)))
    }
  }

  ##########################################
  ####  Detect for new compound clusters ###
  ##########################################
  cat("Detecting New Compound Classes\n")

  finalterm.df.2 <- finalterm.df
  newClustVec <- names(which(table(chemrich.input.file$ClusterNumber[which(finalterm.df.2$Clabel=="")])>3))
  clustMeanvec <- sapply(newClustVec, function(x) {  mean(s[which(chemrich.input.file$ClusterNumber==x),which(chemrich.input.file$ClusterNumber==x)])  }  )
  newClustVec <- newClustVec[which(clustMeanvec>0.70)]
  if(length(newClustVec)>0) {
    for(i in which(finalterm.df.2$Clabel=="")) {
      if(chemrich.input.file$ClusterNumber[i]%in%newClustVec){
        finalterm.df$Clabel[i] <- paste0("NewCluster_",chemrich.input.file$ClusterNumber[i])
      }
    }
  }

  ##### Map the compounds that have atleast 0.75 similarity to others. Only for compunds that do not have any labels.

  for ( i in which(finalterm.df$Clabel=="")) { ## if there is a metabolite that has score higher than 0.80 then we get the class using that compound.
    if(max(s[i,])>0.75) {
      simorder <- order(s[i,],decreasing = T)[which(s[i,][order(s[i,],decreasing = T)]>0.75)]
      simorder.class <- sapply(simorder, function(x) { finalterm.df$Clabel[x]})
      simorder.class <- simorder.class[!is.na(simorder.class)]
      if(simorder.class[1]!=""){
        finalterm.df$Clabel[i] <- simorder.class[which(simorder.class!="")][1]
      } else if(length(simorder.class)>1) {
        finalterm.df$Clabel[i] <- simorder.class[which(simorder.class!="")][1]
      }
    }
  }

  cat("Detecting non-overlapping class definition\n")


  finalterm.df$Count <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(which(finalterm.df$Clabel==x))  }))
  finalterm.df$gCount <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(grep(x,finalterm.df$Clabel))  }))

  exclusionVec <- c("D02","D03.383","D03.633.100","D03.633.300","D03.633.400","D03.633","D03.605","D02.241.081") ## we will have some static list of terms that need to be excluded.
  exclusionVec <- c(exclusionVec, unique(falabelvec)[-1]) ## if we see Fatty acid label, we dont touch them.

  for ( i in which(finalterm.df$gCount<3)) { ## Drop the compound to the neareast one.
    qpat <- gsub("[.][0-9]{2,3}$","",finalterm.df$Clabel[i])
    if(length(grep(qpat,finalterm.df$Clabel))>2 & !qpat%in%exclusionVec){
      finalterm.df$Clabel[i] <- qpat
    }
  }

  finalterm.df$Count <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(which(finalterm.df$Clabel==x))  }))
  finalterm.df$gCount <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(grep(x,finalterm.df$Clabel))  }))

  for ( i in which(finalterm.df$gCount<3)) { ## Map to the closest ones.
    if(max(s[i,])>0.85) {
      simorder <- order(s[i,],decreasing = T)[which(s[i,][order(s[i,],decreasing = T)]>0.85)]
      simorder.class <- sapply(simorder, function(x) { finalterm.df$Clabel[x]})
      simorder.class <- simorder.class[!is.na(simorder.class)]
      if(simorder.class[1]!=""){
        finalterm.df$Clabel[i] <- simorder.class[which(simorder.class!="")][1]
      } else if(length(simorder.class)>1) {
        finalterm.df$Clabel[i] <- simorder.class[which(simorder.class!="")][1]
      }
    }
  }

  finalterm.df$Count <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(which(finalterm.df$Clabel==x))  }))
  finalterm.df$gCount <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(grep(x,finalterm.df$Clabel))  }))

  # Repeat it one more time.
  for ( i in which(finalterm.df$gCount<3)) { ## Drop the compound to the neareast one.
    qpat <- gsub("[.][0-9]{2,3}$","",finalterm.df$Clabel[i])
    if(length(grep(qpat,finalterm.df$Clabel))>2 & !qpat%in%exclusionVec){
      finalterm.df$Clabel[i] <- qpat
    }
  }
  finalterm.df$Count <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(which(finalterm.df$Clabel==x))  }))
  finalterm.df$gCount <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(grep(x,finalterm.df$Clabel))  }))

  for ( i in which(finalterm.df$gCount<3)) { ## Map to the closest ones.
    if(max(s[i,])>0.85) {
      simorder <- order(s[i,],decreasing = T)[which(s[i,][order(s[i,],decreasing = T)]>0.85)]
      simorder.class <- sapply(simorder, function(x) { finalterm.df$Clabel[x]})
      simorder.class <- simorder.class[!is.na(simorder.class)]
      if(simorder.class[1]!=""){
        finalterm.df$Clabel[i] <- simorder.class[which(simorder.class!="")][1]
      } else if(length(simorder.class)>1) {
        finalterm.df$Clabel[i] <- simorder.class[which(simorder.class!="")][1]
      }
    }
  }

  finalterm.df$Count <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(which(finalterm.df$Clabel==x))  }))
  finalterm.df$gCount <- as.integer(sapply(finalterm.df$Clabel, function(x) { length(grep(x,finalterm.df$Clabel))  }))
  finalterm.df$Clabel[which(finalterm.df$Count<3)] <- finalterm.df.2$Clabel[which(finalterm.df$Count<3)] ### We reverse back the original labels as this did not create any higher labels.

  finallabelvec <- finalterm.df$Clabel

  HasSaturatedFats <- names(which(table(finallabelvec[grep("D10|D09.400.410",finallabelvec)[which(sapply(grep("D10|D09.400.410",finallabelvec), function(x)  { length(grep("C=C",chemrich.input.file$SMILES[x]))  })==0)]])>2)) ### we are only selecting lipid classes that has atleast 3 saturated lipids.

  for (i in 1:nrow(finalterm.df)) {
    if(finallabelvec[i]%in%HasSaturatedFats){
      if(length(grep("C=C",chemrich.input.file$SMILES[i]))==0) {
        finallabelvec[i] <- paste0("Saturated_",getCNames(finallabelvec[i]))
      } else {
        finallabelvec[i] <- paste0("Unsaturated_",getCNames(finallabelvec[i]))
      }
    }
  }
  clusterids <- sapply(as.character(finallabelvec),getCNames)
  cat("ChemRICH Class Estimation Finished. ChemRICHClusters column has been added to chemrich.input.file data.frame\n")
  chemrich.input.file$ChemRICHClusters <- clusterids
  chemrich.input.file
}

chemrich.GetSignificantClasses <- function() {
  clusterids <- names(which(table(chemrich.input.file$ChemRICHClusters)>2))
  clusterids <- clusterids[which(clusterids!="")]
  cluster.pvalues <- sapply(clusterids, function(x) { # pvalues were calculated if the set has at least 2 metabolites with less than 0.10 pvalue.
    cl.member <- which(chemrich.input.file$ChemRICHClusters==x)
    if( length(which(chemrich.input.file$pvalue[cl.member]<.05)) >1 ){
      pval.cl.member <- chemrich.input.file$pvalue[cl.member]
      p.test.results <- ks.test(pval.cl.member,"punif",alternative="greater")
      p.test.results$p.value
    } else {
      1
    }
  })

  cluster.pvalues[which(cluster.pvalues==0)] <- 2.2e-20 ### All the zero are rounded to the double.eps pvalues.\

  #clusterdf <- data.frame(name=clusterids[which(cluster.pvalues!=10)],pvalues=cluster.pvalues[which(cluster.pvalues!=10)], stringsAsFactors = F)
  clusterdf <- data.frame(name=clusterids,pvalues=cluster.pvalues, stringsAsFactors = F)

  # clusterdf$keycpd <- sapply(clusterdf$name, function(x) {
  #   dfx <- df1[which(df1$ClusterLabel==x),]
  #   dfx$SMILES[which.min(dfx$pvalue)]
  # })
  clusterdf$keycpdname <- sapply(clusterdf$name, function(x) {
    dfx <- chemrich.input.file[which(chemrich.input.file$ChemRICHClusters==x),]
    dfx$`BIOCHEMICAL NAME`[which.min(dfx$pvalue)]
  })

  altrat <- sapply(clusterdf$name, function (k) {
    length(which(chemrich.input.file$ChemRICHClusters==k & chemrich.input.file$pvalue<0.05))/length(which(chemrich.input.file$ChemRICHClusters==k))
  })

  uprat <-sapply(clusterdf$name, function (k) {
    length(which(chemrich.input.file$ChemRICHClusters==k & chemrich.input.file$pvalue<0.05 & chemrich.input.file$fc > 1.00000000))/length(which(chemrich.input.file$ChemRICHClusters==k & chemrich.input.file$pvalue<0.05))
  })

  clust_s_vec <- sapply(clusterdf$name, function (k) {
    length(which(chemrich.input.file$ChemRICHClusters==k))
  })
  clusterdf$alteredMetabolites <- sapply(clusterdf$name, function (k) {length(which(chemrich.input.file$ChemRICHClusters==k & chemrich.input.file$pvalue<0.05))})
  clusterdf$upcount <- sapply(clusterdf$name, function (k) {length(which(chemrich.input.file$ChemRICHClusters==k & chemrich.input.file$pvalue<0.05 & chemrich.input.file$fc > 1.00000000))})
  clusterdf$downcount <- sapply(clusterdf$name, function (k) {length(which(chemrich.input.file$ChemRICHClusters==k & chemrich.input.file$pvalue<0.05 & chemrich.input.file$fc < 1.00000000))})
  clusterdf$upratio <- uprat
  clusterdf$altratio <- altrat
  clusterdf$csize <- clust_s_vec
  clusterdf <- clusterdf[which(clusterdf$csize>2),]
  clusterdf$adjustedpvalue <- p.adjust(clusterdf$pvalues, method = "fdr")
  clusterdf$xlogp <- as.numeric(sapply(clusterdf$name, function(x) {  median(chemrich.input.file$xlogp[which(chemrich.input.file$ChemRICHClusters==x)]) }))
  clusterdf
}

##
export.chemrich.impactPlot <- function(clusterdf) {

  clusterdf$Compounds <- sapply(clusterdf$name, function(x) {
    dfx <- chemrich.input.file[which(chemrich.input.file$ChemRICHClusters==x),]
    paste(dfx$`BIOCHEMICAL NAME`,collapse="<br>")
  }) ## this one is the label on the tooltip of the ggplotly plot.

  clustdf <- clusterdf[which(clusterdf$pvalues!=1),]
  #################################################
  ########## Impact Visualization Graph ###########
  #################################################

  clustdf.alt.impact <- clustdf[which(clustdf$pvalues<0.05 & clustdf$csize>1 & clustdf$alteredMetabolites>1) ,]

  clustdf.alt.impact <- clustdf.alt.impact[order(clustdf.alt.impact$xlogp),]
  clustdf.alt.impact$order <- 1:nrow(clustdf.alt.impact) ### Order is decided by the hclust algorithm.
  clustdf.alt.impact$logPval <- -log(clustdf.alt.impact$pvalues)

  p2 <- ggplot(clustdf.alt.impact,aes(x=xlogp,y=-log(pvalues)))
  p2 <- p2 + geom_point(aes(size=csize, color=upratio)) +
    #labs(subtitle = "Figure Legend : Point size corresponds to the count of metabolites in the group. Point color shows that proportion of the increased metabolites where red means high and blue means low number of upregulated compounds.")+
    scale_color_gradient(low = "blue", high = "red", limits=c(0,1))+
    scale_size(range = c(5, 30)) +
    scale_y_continuous("-log (pvalue)",limits = c(0, max(-log(clustdf.alt.impact$pvalues))+4  )) +
    scale_x_continuous(" median XlogP of clusters ") +
    theme_bw() +
    #labs(title = "ChemRICH cluster impact plot") +
    geom_label_repel(aes(label = name), color = "gray20",family="Arial",data=subset(clustdf.alt.impact, csize>2),force = 5)+
    theme(text=element_text(family="Arial Black"))+
    theme(
      plot.title = element_text(face="bold", size=30,hjust = 0.5),
      axis.title.x = element_text(face="bold", size=20),
      axis.title.y = element_text(face="bold", size=20, angle=90),
      panel.grid.major = element_blank(), # switch off major gridlines
      panel.grid.minor = element_blank(), # switch off minor gridlines
      legend.position = "none", # manually position the legend (numbers being from 0,0 at bottom left of whole plot to 1,1 at top right)
      legend.title = element_blank(), # switch off the legend title
      legend.text = element_text(size=12),
      legend.key.size = unit(1.5, "lines"),
      legend.key = element_blank(), # switch off the rectangle around symbols in the legend
      legend.spacing = unit(.05, "cm"),
      axis.text.x = element_text(size=10,angle = 0, hjust = 1),
      axis.text.y = element_text(size=15,angle = 0, hjust = 1)
    )

  read_pptx() %>%
    add_slide(layout = "Title and Content", master = "Office Theme") %>%
    ph_with_vg(code = print(p2), type = "body", width=10, height=8, offx =0.0 , offy = 0.0) %>%
    print(target = paste0(project_name,"_chemrich_impact_plot.pptx")) %>%
    invisible()
  ggsave(paste0(project_name,"_chemrich_impact_plot.png"), p2,height = 8, width = 12, dpi=300)
  cat(paste0(project_name,"_chemrich_impact_plot.pptx"," has been created."))
}

export.chemrich.interactivePlot <- function(clusterdf) {
  clusterdf$Compounds <- sapply(clusterdf$name, function(x) {
    dfx <- chemrich.input.file[which(chemrich.input.file$ChemRICHClusters==x),]
    paste(dfx$`BIOCHEMICAL NAME`,collapse="<br>")
  }) ## this one is the label on the tooltip of the ggplotly plot.

  clustdf <- clusterdf[which(clusterdf$pvalues!=1),]
  #################################################
  ########## Impact Visualization Graph ###########
  #################################################

  clustdf.alt.impact <- clustdf[which(clustdf$pvalues<0.05 & clustdf$csize>1 & clustdf$alteredMetabolites>1) ,]

  clustdf.alt.impact <- clustdf.alt.impact[order(clustdf.alt.impact$xlogp),]
  clustdf.alt.impact$order <- 1:nrow(clustdf.alt.impact) ### Order is decided by the hclust algorithm.
  clustdf.alt.impact$logPval <- -log(clustdf.alt.impact$pvalues)

  p2 <- ggplot(clustdf.alt.impact,aes(label=name,label2=pvalues, label3=csize,label4=Compounds))
  p2 <- p2 + geom_point(aes(x=xlogp,y=-log(pvalues),size=csize, color=upratio)) +
    #labs(caption = "Figure Legend : Point size corresponds to the count of metabolites in the group. Point color shows that proportion of the increased metabolites where red means high and blue means low number of upregulated compounds.")+
    scale_color_gradient(low = "blue", high = "red", limits=c(0,1))+
    scale_size(range = c(5, 30)) +
    scale_y_continuous("-log (pvalue)",limits = c(0, max(-log(clustdf.alt.impact$pvalues))+5  )) +
    scale_x_continuous(" median XlogP of clusters ") +
    theme_bw() +
    #labs(title = "ChemRICH cluster impact plot") +
    geom_text(aes(x=xlogp,y=-log(pvalues),label = name), color = "gray20",data=subset(clustdf.alt.impact, csize>2))+
    theme(
      plot.title = element_text(face="bold", size=30,hjust = 0.5),
      axis.title.x = element_text(face="bold", size=20),
      axis.title.y = element_text(face="bold", size=20, angle=90),
      panel.grid.major = element_blank(), # switch off major gridlines
      panel.grid.minor = element_blank(), # switch off minor gridlines
      legend.position = "none", # manually position the legend (numbers being from 0,0 at bottom left of whole plot to 1,1 at top right)
      legend.title = element_blank(), # switch off the legend title
      legend.text = element_text(size=12),
      legend.key.size = unit(1.5, "lines"),
      legend.key = element_blank(), # switch off the rectangle around symbols in the legend
      legend.spacing = unit(.05, "cm"),
      axis.text.x = element_text(size=15,angle = 0, hjust = 1),
      axis.text.y = element_text(size=15,angle = 0, hjust = 1)
    )
  gg <- ggplotly(p2,tooltip = c("label","label2","label4"), width = 1600, height = 1000)
  saveWidget(gg,file = paste0(project_name, "_chemrich_interactive.html"), selfcontained = T)

  #################################
  ### Interactive volcano plot  ###
  #################################
  # we need to add the interactive volcano plot for the p-values and fold-change sorted by the MeSH tree order.
  df2 <- chemrich.input.file
  df2 <- df2[order(sapply(df2$ChemRICHClusters, function(x) { median(df2$xlogp[which(df2$ChemRICHClusters==x)])     }  )),]
  df2$Changed <- "No Change"
  df2$Changed[which(df2$pvalue<0.05 & df2$fc>1)] <- "UP"
  df2$Changed[which(df2$pvalue<0.05 & df2$fc<1)] <- "DOWN"
  df2$Changed <- as.factor(df2$Changed)
  df2$pathway <- "No"
  df2$pathway[which(df2$PubChemID%in%cid_biosys==TRUE)] <- "yes"
  df2$pathway <- as.factor(df2$pathway)
  df2$Compound.Name <- factor(df2$`BIOCHEMICAL NAME`, levels =df2$`BIOCHEMICAL NAME`)
  df2$foldchange <- round(sapply(df2$fc, function(x) { if(x>1) {x} else {1/x} }), digits = 1)
  df2$foldchange[ df2$foldchange>5] <- 5

  p2 <-   ggplot(df2, aes(label=Compound.Name,x=Compound.Name, y=-log(pvalue,base = 10),colour = Changed,shape=pathway, size=foldchange)) +  scale_size(range = c(1, 10)) +
    #geom_line(position=pd, size=2)+
    #geom_errorbar(aes(ymin = V2-V3 , ymax=V2+V3), width=.3,size=2,position=pd) +
    geom_point(stat = "identity") + # 21 is filled circle
    #geom_bar(stat="identity", size=.1,position=position_dodge()) +
    scale_y_continuous("pvalue (-log)") +
    scale_x_discrete("Metabolites: Red- increased,blue-decreased,yellow-not significant, solid-pathway(s) found ") +
    scale_color_manual("Student ttest",values=c("blue", "yellow", "red","white")) +
    scale_fill_manual("",values=c("white", "yellow", "red","white")) +
    scale_shape_manual("Pathway found",values=c(1,16))+
    #scale_shape(solid = FALSE) +
    theme_bw() +
    labs(title = "Metabolic Dys-regulations sorted by chemical similarity") +
    theme(
      plot.title = element_text(face="bold", size=30,hjust = 0.5),
      axis.title.x = element_text(face="bold", size=20),
      axis.title.y = element_text(face="bold", size=30, angle=90),
      panel.grid.major = element_blank(), # switch off major gridlines
      panel.grid.minor = element_blank(), # switch off minor gridlines
      #legend.justification=c(1,0),
      #legend.position=c(1,.6),
      legend.position = "none",
      #legend.title = element_blank(), # switch off the legend title
      #legend.text = element_text(size=12),
      #legend.key.size = unit(1.5, "lines"),
      #legend.key = element_blank(), # switch off the rectangle around symbols in the legend
      #legend.spacing = unit(.05, "cm"),
      #axis.text.x = element_text(size=15,angle = 45, hjust = 1.0),
      axis.text.x= element_blank(),
      axis.text.y = element_text(size=15,angle = 0, hjust = 0.5)
    )
  p3 <- ggplotly(p2, width = 1600, height = 1000)
  saveWidget(gg,file = paste0(project_name, "_chemrich_dysregulation.html"), selfcontained = T)
  cat("Interactive plots have been generated.")
}


## Export Chemical Similarity Tree Plot

plot.fan.chemrich <- function(hc, clus, dirvec,sizevec) {
  letters.x <- c(letters,LETTERS)
  nclus <- length(unique(clus))
  palette <- c('black','green','orange','blue','grey','yellow','pink','brown','purple','violet','skyblue','khaki','lavender','magenta',"gold","sienna","tan","seagreen","orchid","linen","skyblue3","wheat","navyblue","moccasin","navy","dodgerblue","deeppink","chocolate",'red','blue','green','orange','maroon2','grey','yellow','pink','brown','purple','violet','skyblue','khaki','lavender','magenta',"gold","sienna","tan","seagreen","orchid","linen","skyblue3","wheat","navyblue","moccasin","navy","dodgerblue","deeppink","chocolate",'black','green','orange','blue','grey','yellow','pink','brown','purple','violet','skyblue','khaki','lavender','magenta',"gold","sienna","tan","seagreen","orchid","linen","skyblue3","wheat","navyblue","moccasin","navy","dodgerblue","deeppink","chocolate",'red','blue','green','orange','maroon2','grey','yellow','pink','brown','purple','violet','skyblue','khaki','lavender','magenta',"gold","sienna","tan","seagreen","orchid","linen","skyblue3","wheat","navyblue","moccasin","navy","dodgerblue","deeppink","chocolate")
  #[1:nclus]
  X <- as.phylo(hc)
  X$tip.label <- chemrich.input.file$`BIOCHEMICAL NAME`
  #X$tip.label <- as.character(clus)
  X$tip.label[which(dirvec=="yellow")] <- ""
  edge.colors <- rep("lightgray",nrow(X$edge))
  for (i in unique(clus)) {
    if(i>0) {
      difvec <- diff(which(X$edge[,2] %in% which(clus==i)))
      if(length(which(difvec>3))==0) {
        edge.colors[min(which(X$edge[,2] %in% which(clus==i))):max(which(X$edge[,2] %in% which(clus==i)))] <- "black"
        edge.colors[min(which(X$edge[,2] %in% which(clus==i)))-1] <- "black"
        #edge.colors[max(which(X$edge[,2] %in% which(clus==i)))+1] <- "black"
        #nodelabels(LETTERS[k], node=   74, adj=c(0.5,0.5), frame = "c", bg = "white", cex = 1.0)
      } else {
        ovec <- which(X$edge[,2] %in% which(clus==i))
        ovec <- ovec[-1]
        edge.colors[min(ovec):max(ovec)] <- "black"
        edge.colors[min(ovec)-1] <- "black"
      }
    }
  }
  XX <- plot(X,type='fan', tip.color="black",edge.color=edge.colors,show.tip.label = F,edge.width = 2, label.offset=.01, cex=0.5,no.margin=T)
  tiplabels(pch = 21,col = dirvec, bg = dirvec,  cex = sizevec)
  #edgelabels()
  k = 1
  for (i in unique(clus)) {
    if(i>0) {
      difvec <- diff(which(X$edge[,2] %in% which(clus==i)))
      if(length(which(difvec>3))==0) {
        nodeiddf <- as.data.frame(X$edge[min(which(X$edge[,2] %in% which(clus==i))):max(which(X$edge[,2] %in% which(clus==i))),])
        #nodelabels(letters[k], node=min(nodeiddf$V1), adj=c(0.5,0.5), frame = "none", bg = "transparent", cex = 2.0,col="green")
        arc.cladelabels(text=letters.x[k],node=min(nodeiddf$V1),cex = 1.0,lab.offset=1.05,ln.offset=1.01)
        k = k+1
      } else {
        ovec <- which(X$edge[,2] %in% which(clus==i))
        ovec <- ovec[-1]
        nodeiddf <- as.data.frame(X$edge[min(ovec):max(ovec),])
        #nodelabels(letters[k], node=min(nodeiddf$V1), adj=c(0.5,0.5), frame = "none", bg = "transparent", cex = 2.0,col="green")
        arc.cladelabels(text=letters.x[k],node=min(nodeiddf$V1),cex = 1.0,lab.offset=1.05,ln.offset=1.01)
        k = k+1
      }
    }
  }
}

export.chemrich.similarityTree <- function() { # not done yet.

  cat("Computing sub-structure fingerprint\n")
  fps <- t(sapply(1:nrow(chemrich.input.file), function(x) {
    #print(x)
    xy <- 0
    xy <- as.character(rcdk::get.fingerprint(rcdk::parse.smiles(chemrich.input.file$SMILES[x])[[1]],type="pubchem"))
    xy
  }))

  df1.bitmat <- do.call(rbind,lapply(fps,function(x) as.integer(strsplit(x,"")[[1]][1:881])))

  cat("Computing Chemical Similarity\n")
  m <- df1.bitmat
  mat <- m%*%t(m)
  len <- length(m[,1])
  s <- mat.or.vec(len,len)
  for (i in 1:len) {
    for (j in 1:len){
      s[i,j] <- mat[i,j]/(mat[i,i]+mat[j,j]-mat[i,j])
    }
  }
  diag(s) <- 0
  hc <- hclust(as.dist(1-s), method="ward.D2") # ward method provide better clusters.
  clust1 <- cutreeDynamic(hc,distM = as.matrix(1-s),deepSplit =4, minClusterSize = 3)  # can be used to merge cluster, but it is better to keep them as it is. # Clusters are detected using the average linkage hclust.

  treeLabels <- rep("",nrow(chemrich.input.file))

  clus <- as.integer(clust1)
  if(length(which(clus==0))>0) {
    clus[which(clus==0)] <- max(unique(clust1))+1
  }
  sizevec <- rep(1.0,length(clus))
  dirvec <- sapply(chemrich.input.file$fc,function(x){ if(x>1) { return("red") } else (return("blue")) })
  pvaluevec <- chemrich.input.file$pvalue
  pvaluevec[is.na(chemrich.input.file$pvalue)] <- 1 # sometimes we do have pvalues NaN
  dirvec <- sapply(1:length(pvaluevec), function(x) { if(pvaluevec[x]>0.05) {"yellow"} else{dirvec[x]}})
  sizevec[which(dirvec=="yellow")] <- 0.2
  #clus_pval_list <-  sapply(unique(clust1), function(x) { sapply(clust1[which(clust1==x)], function(y) { clusterdf$pvalues[which(clusterdf$name==y)]  }) })
  #alteredClusters <- unique(chemrich.input.file$ChemRICHClusters)[which(unlist(lapply(clus_pval_list, function(xx) { length(which(xx<0.05))/length(xx) }))>0.5)]
  #clus[which(!clus%in%alteredClusters)] <- 0 ## All the clusters that are not altered are turned off with this command
  png(file= paste0(project_name, "_chemical_similarity_tree.png"),width=12,height=15,units="in",res=300)
  plot.fan.chemrich(hc,clus, dirvec,sizevec)
  text(+0.0, +0.8, "ChemRICH : Chemical Similarity Enrichment Analysis", cex = 2.0)
  dev.off()
  cat(paste0(project_name, "_chemical_similarity_tree.png", " has been saved."))
}

#export tables
export.chemrich.tables <- function(clusterdf) {
  clustdf.e <- clusterdf[order(clusterdf$pvalues),]
  clustdf.e$pvalues <- signif(clustdf.e$pvalues, digits = 2)
  clustdf.e$adjustedpvalue <- signif(clustdf.e$adjustedpvalue, digits = 2)
  clustdf.e$upratio <- signif(clustdf.e$upratio, digits = 1)
  clustdf.e$altratio <- signif(clustdf.e$altratio, digits = 1)
  clustdf.e <- clustdf.e[,c("name","csize","pvalues","adjustedpvalue","keycpdname","alteredMetabolites","upcount","downcount","upratio","altratio")]
  names(clustdf.e) <- c("Cluster name","Cluster size","p-values","FDR","Key compound","Altered metabolites","Increased","Decreased","Increased ratio","Altered Ratio")
  #df1$TreeLabels <- treeLabels
  chemrich.input.file$pvalue <- signif(chemrich.input.file$pvalue, digits = 2)
  chemrich.input.file$fc <- signif(chemrich.input.file$fc, digits = 2)
  chemrich.input.file$FDR <- signif(  p.adjust(chemrich.input.file$pvalue), digits = 2)
  # gdf <- datatable(chemrich.input.file,options = list(pageLength = 10), rownames = F)
  # gdf$width  <- "auto"
  # gdf$height <- "auto"
  # saveWidget(gdf,file="compoundlevel.html",selfcontained = F)
  l <- list("ChemRICH_Results" = clustdf.e, "Compound_ChemRICH" = chemrich.input.file )
  openxlsx::write.xlsx(l, file = paste0(project_name, "_ChemRICH_results.xlsx"), asTable = TRUE)
  cat(paste0(project_name, "_ChemRICH_results.xlsx", " has been saved."))
}


### MetaMapp network visualization.

## Chemical Similarity Network Calculation
getChemSimNet <- function (cids, cutoff=0.7,fps1) {
  m <- fps1
  mat <- m%*%t(m)
  len <- length(m[,1])
  s <- mat.or.vec(len,len)
  for (i in 1:len) {
    for (j in 1:len){
      s[i,j] <- mat[i,j]/(mat[i,i]+mat[j,j]-mat[i,j])
    }
  }
  diag(s) <- 0
  #dfmax <- cbind(cids,"tmsim",cids[sapply(1:length(cids), function (k) {which.max(s[k,]) })])
  s[lower.tri(s)]<-0
  return(if(length(which(s>cutoff))>0) {
    return(if(length(which(s>cutoff))==1) {
      chemsimdf <- do.call(rbind,sapply(1:length(cids), function (k) { if(length(which(s[k,]>cutoff))>0) {cbind(cids[k],"tmsim",cids[which(s[k,]>cutoff)])}} ))
      chemsimdf <- rbind(chemsimdf, cbind(cids,"tmsim",""))
      chemsimdf
    } else {
      chemsimdf <- do.call(rbind,sapply(1:length(cids), function (k) { if(length(which(s[k,]>cutoff))>0) {cbind(cids[k],"tmsim",cids[which(s[k,]>cutoff)])}} ))
      chemsimdf <- rbind(chemsimdf, cbind(cids,"tmsim",""))
      ## Duplicated edges removal
      chemsimdf <- chemsimdf[-which(chemsimdf[,3]==""),]
      chemsimdf <- rbind(chemsimdf,cbind(chemsimdf[,3], chemsimdf[,2], chemsimdf[,1]))
      chemsimdf <-  chemsimdf[!duplicated( chemsimdf),]
      chemsimdf <- chemsimdf[order(chemsimdf[,3],decreasing = F),]
      chemsimdf <- chemsimdf[order(chemsimdf[,1],decreasing = F),]
      pmids_a <- cids
      for (i in 1:length(pmids_a)) {
        if(length(which(chemsimdf[,1]==pmids_a[i]))>0) {
          sind <- c((max(which(chemsimdf[,1]==pmids_a[i])) +1) :nrow(chemsimdf))
          chemsimdf[,3][which(chemsimdf[,3][sind]==pmids_a[i]) + (sind[1]-1) ] <- "XX"
        }
      }
      chemsimdf <- chemsimdf[-which(chemsimdf[,3]=="XX"),]
      chemsimdf
    })
  } )#write.table(chemsimdf,file=paste(c("chemsim_",gsub("[.]","",as.character(cutoff)),".sif"),collapse=""), quote=FALSE,sep="\t",col.names=FALSE,row.names=FALSE)  ## To write the cytoscape network file as an output
}
## Tanimoto score calculation was adopted from http://data2quest.blogspot.com/2013/10/fast-tanimoto-similarity-calculation.html

getKEGGRpairs <- function (cids, keggids,fps1, cutoff=0.7) {
  data(krp)
  krp.1 <- match(krp[,1],keggids)
  krp.2 <- match(krp[,2],keggids)
  krp.cbind <- cbind (krp.1,krp.2)
  krp.net <- subset(krp.cbind, krp.1!="NA" & krp.2!="NA")
  krp.cid.net <- NA
  if(nrow(krp.net)==0) { # export only the chemical similarity map
    chemsim <- getChemSimNet(cids,cutoff,fps1)
    krp.cid.net  <- chemsim
  } else {
    cid.krp.2 <- cids[krp.net[,2]]
    cid.krp.1 <- cids[krp.net[,1]]
    krp.cid.net <- cbind(cid.krp.1,"krp",cid.krp.2)
    chemsim <- getChemSimNet(cids,cutoff,fps1)
    krp.cid.net <- rbind(krp.cid.net,chemsim)
  }
  return(krp.cid.net)
}


getCorrelationNetwork <- function(cids,cormat, cutoff=0.80 ) {
  s <- cormat
  diag(s) <- 0
  s[lower.tri(s)]<-0
  return(if(length(which(s>0.80))>0) {
    return(if(length(which(s>0.80))==1) {
      chemsimdf <- do.call(rbind,sapply(1:length(cids), function (k) { if(length(which(s[k,]>cutoff))>0) {cbind(cids[k],"corsim",cids[which(s[k,]>cutoff)])}} ))
      chemsimdf
    } else {
      chemsimdf <- do.call(rbind,sapply(1:length(cids), function (k) { if(length(which(s[k,]>cutoff))>0) {cbind(cids[k],"tmsim",cids[which(s[k,]>cutoff)])}} ))
      ## Duplicated edges removal
      chemsimdf <- chemsimdf[which(chemsimdf[,3]!=""),]
      chemsimdf <- rbind(chemsimdf,cbind(chemsimdf[,3], chemsimdf[,2], chemsimdf[,1]))
      chemsimdf <-  chemsimdf[!duplicated( chemsimdf),]
      chemsimdf <- chemsimdf[order(chemsimdf[,3],decreasing = F),]
      chemsimdf <- chemsimdf[order(chemsimdf[,1],decreasing = F),]
      pmids_a <- cids
      for (i in 1:length(pmids_a)) {
        if(length(which(chemsimdf[,1]==pmids_a[i]))==0) next
        sind <- c((max(which(chemsimdf[,1]==pmids_a[i])) +1) :nrow(chemsimdf))
        chemsimdf[,3][which(chemsimdf[,3][sind]==pmids_a[i]) + (sind[1]-1) ] <- "XX"
      }
      chemsimdf <- chemsimdf[-which(chemsimdf[,3]=="XX"),]
      chemsimdf[,2] <- "corsim"
      chemsimdf
    })
  })
}

getIntegratedNetwork <- function(moduleName) {
  dd.sb <- chemrich.input.file[which(chemrich.input.file$ChemRICHClusters==moduleName),]
  dd.sb$SMILES[which(dd.sb$SMILES==0 | dd.sb$SMILES=="")] <- NA
  # chemical similarity links
  fps <- t(sapply(dd.sb$SMILES, function(x) {
    if(!is.na(x))
      as.character(rcdk::get.fingerprint(rcdk::parse.smiles(x)[[1]],type="pubchem"))
  }))
  df1.bitmat <- do.call(rbind,lapply(fps,function(x) {
    if(!is.null(x)) {
      as.integer(strsplit(x,"")[[1]][1:881])
    } else {
      rep(0,881)
    }
  }))
  metamapp.network <- getKEGGRpairs(dd.sb$CompoundID, dd.sb$KEGG,df1.bitmat, cutoff=0.7)
  if(is.null(metamapp.network)) {
    metamapp.network <- data.frame(NA,NA,NA)
  }
  ## correlation network
  data_matrix.sb <- as.data.frame(data_matrix[which(chemrich.input.file$ChemRICHClusters==moduleName),-1]) # Only numeric values
  data_matrix.sb <- do.call(rbind,lapply(1:nrow(data_matrix.sb),function(x) {as.numeric(data_matrix.sb[x,])}))
  cormat <- cor(t(data_matrix.sb), method = "spearman")
  cornet <- data.frame(NA,NA,NA)
  if (length(which(cormat>0.80)) > nrow(dd.sb)) {
    cornet <- getCorrelationNetwork(dd.sb$CompoundID, cormat, cutoff = 0.8)
  }
  # Network Visualization
  edges.a <- data.frame(to=NA, from=NA, color="yellow", stringsAsFactors = F)
  if(length(which(metamapp.network[,2]=="tmsim"))!=0) {
    edges.a <- data.frame(to=metamapp.network[which(metamapp.network[,2]=="tmsim"),1], from = metamapp.network[which(metamapp.network[,2]=="tmsim"),3], color="yellow", stringsAsFactors = F)
  }
  edges.b <- data.frame(to=cornet[,1], from = cornet[,3], color="green", stringsAsFactors = F)
  edges.c <- data.frame(to=NA, from=NA, color="red", stringsAsFactors = F)
  if(length(which(metamapp.network[,2]=="krp"))!=0) {
    edges.c <- data.frame(to=metamapp.network[which(metamapp.network[,2]=="krp"),1], from = metamapp.network[which(metamapp.network[,2]=="krp"),3], color="red")
  }
  netdf <- rbind(edges.a, edges.b, edges.c)
  netdf <- netdf[!is.na(netdf$to),]
  netdf <- netdf[which(netdf$from!=""),]
  netdf
}

## Export the module network - correlation, chemical similarity and biochemical links
chemrich.getIntegratedNetwork <- function(moduleName,compoundLabel) {
  dd.sb <- chemrich.input.file[which(chemrich.input.file$ChemRICHClusters==moduleName),]
  dirvec <- sapply(dd.sb$fc,function(x) {ifelse(x>1, "red","blue")})
  dirvec[which(dd.sb$pvalue>0.05)] <- "yellow"
  sizevec <- sapply(dd.sb$fc,function(x) {ifelse(x>1, x,1/x)})
  sizevec[which(dd.sb$pvalue>0.05)] <- 1
  sizevec <- round(sizevec, digits = 1)
  int_net <- getIntegratedNetwork(moduleName)
  nodes <- data.frame(id=dd.sb$CompoundID,label = dd.sb[[compoundLabel]],title = dd.sb[[compoundLabel]], color=dirvec, size=sizevec*30)
  visNetwork(nodes, int_net, main= list(text=paste0("metabolite module : ",moduleName)),
    footer=list(text="Edges - Green = Correlation (>0.80), Yellow = Chemical Similarity (>0.70),
Red = KEGG Reaction Pairs <br> Nodes- Red = UP, Blue = Down, Yellow=No Change", style="position: absolute;top:80%;left:25%") ) %>%
    visNodes(font=list(size=50,vadjust = -40), physics=F) %>%
    visEdges(smooth = list(enabled = T, type = 'dynamic'), width=10) %>%
    visPhysics(solver = "barnesHut", barnesHut = list(springConstant = 0.002)) %>%
    visOptions(manipulation = TRUE)
}

## Get relationship summary
getRelationshipSummary <- function() {
  modvec <- as.numeric(clustdf.x$`Module name`)
  edge_type_count <- lapply(modvec, function(x){
    print(paste("Calculating module ",x))
    int_net <- getIntegratedNetwork(x)
    link.df <- table(int_net$color)
    corcount <- 0
    if(length(which(names(link.df)=="green"))>0) {
      corcount <-as.numeric(link.df[which(names(link.df)=="green")])
    }
    chemcount <- 0
    if(length(which(names(link.df)=="yellow"))>0) {
      chemcount <-as.numeric(link.df[which(names(link.df)=="yellow")])
    }
    keggcount <- 0
    if(length(which(names(link.df)=="red"))>0) {
      keggcount <- as.numeric(link.df[which(names(link.df)=="red")])
    }
    c(corcount, chemcount, keggcount)
  })
  edge.t.df <- data.frame(do.call(rbind,edge_type_count), stringsAsFactors = F)
  edge.t.df
}

# Generate box and whisker plots.
chemrich.generateBWplots <- function(moduleName,compoundLabel) {
  dir.create(paste0("bwplot_module_",moduleName))
  dd.sb <- chemrich.input.file[which(chemrich.input.file$ChemRICHClusters==moduleName),]
  dm.sb <- data_matrix[which(chemrich.input.file$ChemRICHClusters==moduleName),]
  for(i in 1:nrow(dm.sb)) {
    data_bw <- data.frame(group = sample_metadata[[grouping_variable]],metabolite = as.numeric(dm.sb[i,-1]))
    data_bw$group <- as.factor(data_bw$group)
    p <- ggboxplot(data_bw, x = "group", y = "metabolite", add = "jitter",title=dd.sb[[compoundLabel]][i])
    my_comparisons <- list(as.character(unique(data_bw$group)))
    p1 <- p + stat_compare_means(comparisons = my_comparisons) # Add pairwise comparisons p-value
    #stat_compare_means(label.y = max(data_bw$metabolite)+mean(data_bw$metabolite)/2)
    read_pptx() %>%
      add_slide(layout = "Title and Content", master = "Office Theme") %>%
      ph_with_vg(code = print(p1), type = "body", width = 10,height = 7, offx = .3, offy = .3) %>%
      print(target = paste(c("./bwplot_module_",moduleName,"/",dd.sb$CompoundID[i],"_bw.pptx"), collapse="")) %>%
      invisible()
  }
}

## Chemical enrichment analysis for arbiterary classes.
runChemRICHClass <- function(filename,project_name) {
  xdf <- readxl::read_excel(filename, sheet = 1)
  clusterids <- names(which(table(xdf$class)>2))
  clusterids <- clusterids[which(clusterids!="")]
  cluster.pvalues <- sapply(clusterids, function(x) { # pvalues were calculated if the set has at least 2 metabolites with less than 0.10 pvalue.
    cl.member <- which(xdf$class==x)
    if( length(which(xdf$pvalue[cl.member]<.05)) >1 ){
      pval.cl.member <- xdf$pvalue[cl.member]
      p.test.results <- ks.test(pval.cl.member,"punif",alternative="greater")
      p.test.results$p.value
    } else {
      1
    }
  })
  cluster.pvalues[which(cluster.pvalues==0)] <- 2.2e-20 ### All the zero are rounded to the double.eps pvalues.\
  #clusterdf <- data.frame(name=clusterids[which(cluster.pvalues!=10)],pvalues=cluster.pvalues[which(cluster.pvalues!=10)], stringsAsFactors = F)
  clusterdf <- data.frame(name=clusterids,pvalues=cluster.pvalues, stringsAsFactors = F)
  # clusterdf$keycpd <- sapply(clusterdf$name, function(x) {
  #   dfx <- df1[which(df1$ClusterLabel==x),]
  #   dfx$SMILES[which.min(dfx$pvalue)]
  # })
  clusterdf$keycpdname <- sapply(clusterdf$name, function(x) {
    dfx <- xdf[which(xdf$class==x),]
    dfx$`compound name`[which.min(dfx$pvalue)]
  })
  altrat <- sapply(clusterdf$name, function (k) {
    length(which(xdf$class==k & xdf$pvalue<0.05))/length(which(xdf$class==k))
  })
  uprat <-sapply(clusterdf$name, function (k) {
    length(which(xdf$class==k & xdf$pvalue<0.05 & xdf$foldchange > 1.00000000))/length(which(xdf$class==k & xdf$pvalue<0.05))
  })
  clust_s_vec <- sapply(clusterdf$name, function (k) {
    length(which(xdf$class==k))
  })
  clusterdf$alteredMetabolites <- sapply(clusterdf$name, function (k) {length(which(xdf$class==k & xdf$pvalue<0.05))})
  clusterdf$upcount <- sapply(clusterdf$name, function (k) {length(which(xdf$class==k & xdf$pvalue<0.05 & xdf$foldchange > 1.00000000))})
  clusterdf$downcount <- sapply(clusterdf$name, function (k) {length(which(xdf$class==k & xdf$pvalue<0.05 & xdf$foldchange < 1.00000000))})
  clusterdf$upratio <- uprat
  clusterdf$altratio <- altrat
  clusterdf$csize <- clust_s_vec
  clusterdf <- clusterdf[which(clusterdf$csize>2),]
  clusterdf$adjustedpvalue <- p.adjust(clusterdf$pvalues, method = "fdr")
  clusterdf$xlogp <- as.numeric(sapply(clusterdf$name, function(x) {  median(xdf$order[which(xdf$class==x)]) }))
  clusterdf
  clusterdf$Compounds <- sapply(clusterdf$name, function(x) {
    dfx <- xdf[which(xdf$class==x),]
    paste(dfx$`compound name`,collapse="<br>")
  }) ## this one is the label on the tooltip of the ggplotly plot.
  clustdf <- clusterdf[which(clusterdf$pvalues!=1),]
  #################################################
  ########## Impact Visualization Graph ###########
  #################################################
  clustdf.alt.impact <- clustdf[which(clustdf$pvalues<0.05 & clustdf$csize>1 & clustdf$alteredMetabolites>1) ,]
  clustdf.alt.impact <- clustdf.alt.impact[order(clustdf.alt.impact$xlogp),]
  clustdf.alt.impact$order <- 1:nrow(clustdf.alt.impact) ### Order is decided by the hclust algorithm.
  clustdf.alt.impact$logPval <- -log(clustdf.alt.impact$pvalues)
  p2 <- ggplot(clustdf.alt.impact,aes(x=xlogp,y=-log(pvalues)))
  p2 <- p2 + geom_point(aes(size=csize, color=upratio)) +
    #labs(subtitle = "Figure Legend : Point size corresponds to the count of metabolites in the group. Point color shows that proportion of the increased metabolites where red means high and blue means low number of upregulated compounds.")+
    scale_color_gradient(low = "blue", high = "red", limits=c(0,1))+
    scale_size(range = c(5, 30)) +
    scale_y_continuous("-log (pvalue)",limits = c(0, max(-log(clustdf.alt.impact$pvalues))+4  )) +
    scale_x_continuous(" cluster order (as provided) ") +
    theme_bw() +
    #labs(title = "ChemRICH cluster impact plot") +
    geom_label_repel(aes(label = name), color = "gray20",family="Arial",data=subset(clustdf.alt.impact, csize>2),force = 5)+
    theme(text=element_text(family="Arial Black"))+
    theme(
      plot.title = element_text(face="bold", size=30,hjust = 0.5),
      axis.title.x = element_text(face="bold", size=20),
      axis.title.y = element_text(face="bold", size=20, angle=90),
      panel.grid.major = element_blank(), # switch off major gridlines
      panel.grid.minor = element_blank(), # switch off minor gridlines
      legend.position = "none", # manually position the legend (numbers being from 0,0 at bottom left of whole plot to 1,1 at top right)
      legend.title = element_blank(), # switch off the legend title
      legend.text = element_text(size=12),
      legend.key.size = unit(1.5, "lines"),
      legend.key = element_blank(), # switch off the rectangle around symbols in the legend
      legend.spacing = unit(.05, "cm"),
      axis.text.x = element_text(size=10,angle = 0, hjust = 1),
      axis.text.y = element_text(size=15,angle = 0, hjust = 1)
    )
  read_pptx() %>%
    add_slide(layout = "Title and Content", master = "Office Theme") %>%
    ph_with_vg(code = print(p2), type = "body", width=10, height=8, offx =0.0 , offy = 0.0) %>%
    print(target = paste0(project_name,"_chemrich_class_impact_plot.pptx")) %>%
    invisible()
  ggsave(paste0(project_name,"_chemrich_class_impact_plot.png"), p2,height = 8, width = 12, dpi=300)
  cat(paste0(project_name,"_chemrich_class_impact_plot.pptx"," has been created.\n"))

  ## Export the result table.
  clustdf.e <- clusterdf[order(clusterdf$pvalues),]
  clustdf.e$pvalues <- signif(clustdf.e$pvalues, digits = 2)
  clustdf.e$adjustedpvalue <- signif(clustdf.e$adjustedpvalue, digits = 2)
  clustdf.e$upratio <- signif(clustdf.e$upratio, digits = 1)
  clustdf.e$altratio <- signif(clustdf.e$altratio, digits = 1)
  clustdf.e <- clustdf.e[,c("name","csize","pvalues","adjustedpvalue","keycpdname","alteredMetabolites","upcount","downcount","upratio","altratio")]
  names(clustdf.e) <- c("Cluster name","Cluster size","p-values","FDR","Key compound","Altered metabolites","Increased","Decreased","Increased ratio","Altered Ratio")
  #df1$TreeLabels <- treeLabels
  xdf$pvalue <- signif(xdf$pvalue, digits = 2)
  xdf$foldchange <- signif(xdf$foldchange, digits = 2)
  xdf$FDR <- signif(  p.adjust(xdf$pvalue), digits = 2)
  l <- list("ChemRICH_Results" = clustdf.e, "Compound_ChemRICH" = xdf )
  openxlsx::write.xlsx(l, file = paste0(project_name, "_ChemRICH_class_results.xlsx"), asTable = TRUE)
  cat(paste0(project_name, "_ChemRICH_class_results.xlsx", " has been saved.\n"))
}

## ChemRICH workflow for multiple groups.

#project_name <- "chemrich_1" # Provide this analysis a name. This will be prefixed to all the exported files.
#classVariable <- "Class"
#inputfile <- "20181015_KOMP_chemrich_input.xlsx"

chemrih_multi_group <- function(inputfile) {
  data_dict <- readxl::read_xlsx(inputfile, sheet="data_dict") # Data Dictionary
  pvalvec <- grep("pvalue",names(data_dict))
  classVec <- names(which(table(data_dict[[classVariable]])>2))
  clusterids <- classVec[which(classVec!="")]
  data_dict$xlogp  =  as.numeric(sapply(data_dict$SMILES, function(x)  { rcdk::get.xlogp(rcdk::parse.smiles(x)[[1]]) }))

  l <- list("ChemRICH_Input" = data_dict)

  for(k in pvalvec) {
    df1 <- data.frame(Compound = data_dict$Compound_Name, Class = data_dict[[classVariable]], xlogp = data_dict$xlogp, SMILES = data_dict$SMILES, pvalue= as.numeric(data_dict[[k]]), foldchange= as.numeric(data_dict[[k+1]]), stringsAsFactors = F)

    ## Get CHEMRICH computation
    cluster.pvalues <- sapply(clusterids, function(x) { # pvalues were calculated if the set has at least 2 metabolites with less than 0.10 pvalue.
      cl.member <- which(df1$Class==x)
      if( length(which(df1$pvalue[cl.member]<.05)) >1 ){
        pval.cl.member <- df1$pvalue[cl.member]
        p.test.results <- ks.test(pval.cl.member,"punif",alternative="greater")
        p.test.results$p.value
      } else {
        1
      }
    })

    cluster.pvalues[which(cluster.pvalues==0)] <- 2.2e-20 ### All the zero are rounded to the double.eps pvalues.\
    clusterdf <- data.frame(name=clusterids,pvalues=cluster.pvalues, stringsAsFactors = F)

    clusterdf$keycpdname <- sapply(clusterdf$name, function(x) {
      dfx <- df1[which(df1$Class==x),]
      dfx$Compound[which.min(dfx$pvalue)]
    })

    altrat <- sapply(clusterdf$name, function (k) {
      length(which(df1$Class==k & df1$pvalue<0.05))/length(which(df1$Class==k))
    })

    uprat <-sapply(clusterdf$name, function (k) {
      length(which(df1$Class==k & df1$pvalue<0.05 & df1$foldchange > 1.00000000))/length(which(df1$Class==k & df1$pvalue<0.05))
    })

    clust_s_vec <- sapply(clusterdf$name, function (k) {
      length(which(df1$Class==k))
    })

    clusterdf$alteredMetabolites <- sapply(clusterdf$name, function (k) {length(which(df1$Class==k & df1$pvalue<0.05))})
    clusterdf$upcount <- sapply(clusterdf$name, function (k) {length(which(df1$Class==k & df1$pvalue<0.05 & df1$foldchange > 1.00000000))})
    clusterdf$downcount <- sapply(clusterdf$name, function (k) {length(which(df1$Class==k & df1$pvalue<0.05 & df1$foldchange < 1.00000000))})
    clusterdf$upratio <- uprat
    clusterdf$altratio <- altrat
    clusterdf$csize <- clust_s_vec
    clusterdf <- clusterdf[which(clusterdf$csize>2),]
    clusterdf$adjustedpvalue <- p.adjust(clusterdf$pvalues, method = "fdr")
    clusterdf$xlogp <- as.numeric(sapply(clusterdf$name, function(x) {  median(df1$xlogp[which(df1$Class==x)]) }))
    #clusterdf
    clusterdf$Compounds <- sapply(clusterdf$name, function(x) {
      dfx <- df1[which(df1$Class==x),]
      paste(dfx$Compound,collapse="<br>")
    }) ## this one is the label on the tooltip of the ggplotly plot.
    clustdf <- clusterdf[which(clusterdf$pvalues!=1),]

    #################################################
    ########## Impact Visualization Graph ###########
    #################################################

    clustdf.alt.impact <- clustdf[which(clustdf$pvalues<0.05 & clustdf$csize>1 & clustdf$alteredMetabolites>1) ,]
    clustdf.alt.impact <- clustdf.alt.impact[order(clustdf.alt.impact$xlogp),]
    clustdf.alt.impact$order <- 1:nrow(clustdf.alt.impact) ### Order is decided by the hclust algorithm.
    clustdf.alt.impact$logPval <- -log(clustdf.alt.impact$pvalues)

    p2 <- ggplot(clustdf.alt.impact,aes(x=xlogp,y=-log(pvalues)))
    p2 <- p2 + geom_point(aes(size=csize, color=upratio)) +
      #labs(subtitle = "Figure Legend : Point size corresponds to the count of metabolites in the group. Point color shows that proportion of the increased metabolites where red means high and blue means low number of upregulated compounds.")+
      scale_color_gradient(low = "blue", high = "red", limits=c(0,1))+
      scale_size(range = c(5, 30)) +
      scale_y_continuous("-log (pvalue)",limits = c(0, max(-log(clustdf.alt.impact$pvalues))+4  )) +
      scale_x_continuous(" Lipophilicity ", limit=c(min(df1$xlogp)-2,max(df1$xlogp)+2)) +
      theme_bw() +
      labs(title = paste0("ChemRICH cluster impact plot for ", gsub("_pvalue","",names(data_dict)[k]))) +
      geom_label_repel(aes(label = name), color = "gray20",family="Arial",data=subset(clustdf.alt.impact, csize>2),force = 5)+
      theme(text=element_text(family="Arial Black"))+
      theme(
        plot.title = element_text(face="bold", size=30,hjust = 0.5),
        axis.title.x = element_text(face="bold", size=20),
        axis.title.y = element_text(face="bold", size=20, angle=90),
        panel.grid.major = element_blank(), # switch off major gridlines
        panel.grid.minor = element_blank(), # switch off minor gridlines
        legend.position = "none", # manually position the legend (numbers being from 0,0 at bottom left of whole plot to 1,1 at top right)
        legend.title = element_blank(), # switch off the legend title
        legend.text = element_text(size=12),
        legend.key.size = unit(1.5, "lines"),
        legend.key = element_blank(), # switch off the rectangle around symbols in the legend
        legend.spacing = unit(.05, "cm"),
        axis.text.x = element_text(size=10,angle = 0, hjust = 1),
        axis.text.y = element_text(size=15,angle = 0, hjust = 1)
      )

    read_pptx() %>%
      add_slide(layout = "Title and Content", master = "Office Theme") %>%
      ph_with_vg(code = print(p2), type = "body", width=10, height=8, offx =0.0 , offy = 0.0) %>%
      print(target = paste0(project_name,"_",gsub("_pvalue","",names(data_dict)[k]),"_chemrich_impact_plot.pptx")) %>%
      invisible()
    ggsave(paste0(project_name,"_",gsub("_pvalue","",names(data_dict)[k]),"_chemrich_impact_plot.png"), p2,height = 8, width = 12, dpi=300)
    cat(paste0(project_name,"_",gsub("_pvalue","",names(data_dict)[k]),"_chemrich_impact_plot.pptx"," has been created.\n"))

    clustdf.e <- clusterdf[order(clusterdf$pvalues),]
    clustdf.e$pvalues <- signif(clustdf.e$pvalues, digits = 2)
    clustdf.e$adjustedpvalue <- signif(clustdf.e$adjustedpvalue, digits = 2)
    clustdf.e$upratio <- signif(clustdf.e$upratio, digits = 1)
    clustdf.e$altratio <- signif(clustdf.e$altratio, digits = 1)
    clustdf.e <- clustdf.e[,c("name","csize","pvalues","adjustedpvalue","keycpdname","alteredMetabolites","upcount","downcount","upratio","altratio")]
    names(clustdf.e) <- c("Cluster name","Cluster size","p-values","FDR","Key compound","Altered metabolites","Increased","Decreased","Increased ratio","Altered Ratio")
    l[[gsub("_pvalue","",names(data_dict)[k])]] <- clustdf.e
  }
  openxlsx::write.xlsx(l, file = paste0(project_name, "_ChemRICH_results.xlsx"), asTable = TRUE)
  cat(paste0(project_name, "_ChemRICH_results.xlsx", " has been saved.\n"))
}


