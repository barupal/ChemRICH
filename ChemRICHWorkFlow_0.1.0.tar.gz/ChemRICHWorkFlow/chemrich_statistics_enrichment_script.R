project_name <- "chemrich_1" # Provide this analysis a name. This will be prefixed to all the exported files.
ChemRICHWorkFlow::load.ChemRICH.Packages()
ChemRICHWorkFlow::load.ChemRICH.databases()
data_dict <- readxl::read_xlsx("chemrich_input_stats.xlsx", sheet="input") # Data Dictionary
chemrich.input.file <- check.chemrich.input()
chemrich.input.file <- chemrich.getChemicalClass()
signif.chemrich.cluster <- chemrich.GetSignificantClasses()
export.chemrich.impactPlot(signif.chemrich.cluster)
export.chemrich.interactivePlot(signif.chemrich.cluster)
export.chemrich.similarityTree()
export.chemrich.tables(signif.chemrich.cluster)
