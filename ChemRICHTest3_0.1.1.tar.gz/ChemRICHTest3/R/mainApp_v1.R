#raw_data <- readChar("./inst/www/chemrich_example_template_class.txt", nchars = 10000000)
#stat_file = raw_data

# load("./data/cidmesh_smiles_fpbit.RData")  ###df.mega.mesh.unique Unique CIDS
# load("./data/mesh_bit_loc_list.RData") #bitloclist bit locations for the unique CIDS.
# load("./data/treenames.df.RData") ### Name of the TreeBranches.
# load("./data/PubChemMeshCounts.RData") # pubchemdata counts of CIDs and PMIDS for each mesh category.
# load("./data/cidsbiosys.RData") # CID with BioSystems Mapping.

getChemRichClasses <- function (stat_file,cutoff=0.1) {
  letters.x <- c(letters,LETTERS)
  stat_file <- gsub("\r","",stat_file)
  cfile <- strsplit(stat_file,"\n")[[1]]
  df1 <- do.call(rbind, lapply(cfile, function (x) { strsplit(x,"\t")[[1]]  } ))
  #df1 <- df1[c(1:96),]
  colnames(df1) <- sapply(df1[1,],as.character)
  df1 <- df1[-1,]
  df1 <- data.frame(df1,stringsAsFactors = F)
  df1$foldchange <- sapply(df1$foldchange, function(x) { as.numeric(as.character(x))  })
  df1$pvalue <- sapply(df1$pvalue, function(x) { as.numeric(as.character(x))  })
  df1$CID <- as.integer(df1$Pubchem.ID)
  #df1$NewCID <- as.character(df1$CID)

  if( cfile[[1]]!="Compound Name\tInChiKeys\tPubchem ID\tSMILES\tpvalue\tfoldchange\tclass" ) { stop("Please use exact header as provided in the template file.") }
  ### If SMILES code is missing for even one metabolite, we will break the script and ends here.
  if( (length(which(is.na(df1$SMILES)==TRUE)))) { stop("Missing SMILES codes. Please check the input.") }
  if( (length(which(is.na(df1$CID)==TRUE)) & length(which(is.na(df1$SMILES)==TRUE)))) { stop("Missing SMILES codes. Please check the input.") }
  if( length(which(table(df1$CID)>1))>0 ) { stop("Please remove the duplicates CIDs") }
  if( length(which(table(df1$Compound.Name)>1))>0 ) { stop("Please remove the duplicates compound names") }
  if( length(table(is.na(df1$pvalue)))==2 ) { stop("Missing pvalue") }
  if( length(table(is.na(df1$foldchange)))==2 ) { stop("Missing foldchange or effect size") }

  pacman::p_load(officer,openxlsx,grid,RJSONIO,RCurl,dynamicTreeCut,ape,ggplot2,ggrepel,phytools,plotrix,plotly, htmlwidgets,DT,extrafont,devEMF,rvg,magrittr)# better idea will be to load the packages as needed.
  #loadfonts(quiet = T)
  #df.mega.mesh$CompoundName <- tolower(df.mega.mesh$CompoundName)
  #treenames.df$ClassName <- tolower(treenames.df$ClassName)
  ### Calculating xlogp values.

  df1$xlogp <- as.numeric(sapply(df1$SMILES, function(x)  { rcdk::get.xlogp(rcdk::parse.smiles(x)[[1]]) }))
  ###########################################
  #### Detection of Fatty Acid Clusters #####
  ###########################################

  #exc <- XLConnect::loadWorkbook("ChemRICH_results.xlsx", create = T)

  ### Get the FP annotations from the CouchDB using CIDS
  idlist <- list()
  idlist$keys <- as.integer(df1$CID)[which(is.na(df1$CID)==FALSE)]
  urlres <- getURL("http://localhost:5984/chemrichdb_cidfp/_design/data/_view/cid_fp",customrequest='POST',httpheader=c('Content-Type'='application/json'),postfields=RJSONIO::toJSON(idlist))
  urlres.list <- RJSONIO::fromJSON(urlres)
  cid.fp.df <- as.data.frame(do.call(rbind, urlres.list$rows), stringsAsFactors = F)

  ### Get the FP annotations from the CouchDB using SMILES
  idlist <- list()
  idlist$keys <- df1$SMILES
  urlres <- getURL("http://localhost:5984/chemrichdb_smilesfp/_design/data/_view/smiles_fp",customrequest='POST',httpheader=c('Content-Type'='application/json'),postfields=RJSONIO::toJSON(idlist))
  urlres.list <- RJSONIO::fromJSON(urlres)
  smiles.fp.df <- as.data.frame(do.call(rbind, urlres.list$rows), stringsAsFactors = F)

  fps <- t(sapply(1:nrow(df1), function(x) {
    #print(x)
    xy <- 0
    if(is.na(df1$CID[x]) | length(which(smiles.fp.df$key==df1$SMILES[x]))!=0  ) {
      whichsmiles <- which(smiles.fp.df$key==df1$SMILES[x])
      if (length(whichsmiles)!=0) {
        xy <- smiles.fp.df$value[whichsmiles][[1]]
      } else {
        xy <- as.character(rcdk::get.fingerprint(rcdk::parse.smiles(df1$SMILES[x])[[1]],type="pubchem"))
      }
    } else {
      whichcid <- which(cid.fp.df$key==df1$CID[x])
      if (length(whichcid)!=0) {
        xy <- cid.fp.df$value[whichcid][[1]]
      } else {
        xy <- as.character(rcdk::get.fingerprint(rcdk::parse.smiles(df1$SMILES[x])[[1]],type="pubchem"))
      }
    }
    xy
  }))

  ### If any of the smiles codes are wrong. Break the code here.
  if( (length(which(fps==0))>0)) { stop("Incorrect SMILES Code provided. Please check the input") }

  misseddf <- data.frame(SMILES=(df1$SMILES[which(df1$SMILES%in%smiles.fp.df$key!=TRUE)]), FP=fps[which(df1$SMILES%in%smiles.fp.df$key!=TRUE)], stringsAsFactors = F)
  if(nrow(misseddf)!=0) {
    elist <- list()
    for (i in 1:nrow(misseddf)) {
      elist[[i]] <- list()
      elist[[i]]$SMILES<- misseddf$SMILES[i]
      elist[[i]]$FP <- misseddf$FP[i]
    }
    elist1<- list()
    elist1$docs <- elist
    urlres <- getURL("http://localhost:5984/chemrichdb_smilesfp/_bulk_docs",customrequest='POST',httpheader=c('Content-Type'='application/json'),postfields=RJSONIO::toJSON(elist1))
    gc()
  }


  df1.bitmat <- do.call(rbind,lapply(fps,function(x) as.integer(strsplit(x,"")[[1]][1:881])))


  #############################################################
  #### Calculation of the simialrity tree and its clustering ##
  #############################################################

  m <- df1.bitmat
  mat <- m%*%t(m)
  len <- length(m[,1])
  s <- mat.or.vec(len,len)
  for (i in 1:len) {
    for (j in 1:len){
      s[i,j] <- mat[i,j]/(mat[i,i]+mat[j,j]-mat[i,j])
    }
  }
  diag(s) <- 0

  ### Tree Calculation and the ordering of the matrix.

  hc <- hclust(as.dist(1-s), method="ward.D") # ward method provide better clusters.
  glaydf2 <- df1
  df1.order <- df1[hc$order,]

  #############################################
  ### Calculation of Enrichment Statistics#####
  #############################################

  clusterids <- names(which(table(df1$class)>2))
  clusterids <- clusterids[which(clusterids!="")] ## get rid of the empty cells.

  cluster.pvalues <- sapply(clusterids, function(x) { # pvalues were calculated if the set has at least 2 metabolites with less than 0.10 pvalue.
    cl.member <- which(df1$class==x)
    if( length(which(df1$pvalue[cl.member]<.05)) >1 ){
      pval.cl.member <- df1$pvalue[cl.member]
      p.test.results <- ks.test(pval.cl.member,"punif",alternative="greater")
      p.test.results$p.value
    } else {
      1
    }
  })

  cluster.pvalues[which(cluster.pvalues==0)] <- 2.2e-20 ### All the zero are rounded to the double.eps pvalues.\
  clusterdf <- data.frame(name=clusterids,pvalues=cluster.pvalues, stringsAsFactors = F)

  clusterdf$keycpdname <- sapply(clusterdf$name, function(x) {
    dfx <- df1[which(df1$class==x),]
    dfx$Compound.Name[which.min(dfx$pvalue)]
  })

  altrat <- sapply(clusterdf$name, function (k) {
    length(which(df1$class==k & df1$pvalue<0.05))/length(which(df1$class==k))
  })

  uprat <-sapply(clusterdf$name, function (k) {
    length(which(df1$class==k & df1$pvalue<0.05 & df1$foldchange > 1.00000000))/length(which(df1$class==k))
  })

  clust_s_vec <- sapply(clusterdf$name, function (k) {
    length(which(df1$class==k))
  })

  clusterdf$alteredMetabolites <- sapply(clusterdf$name, function (k) {length(which(df1$class==k & df1$pvalue<0.05))})
  clusterdf$upcount <- sapply(clusterdf$name, function (k) {length(which(df1$class==k & df1$pvalue<0.05 & df1$foldchange > 1.00000000))})
  clusterdf$downcount <- sapply(clusterdf$name, function (k) {length(which(df1$class==k & df1$pvalue<0.05 & df1$foldchange < 1.00000000))})
  clusterdf$upratio <- uprat
  clusterdf$altratio <- altrat
  clusterdf$csize <- clust_s_vec
  clusterdf <- clusterdf[which(clusterdf$csize>2),]
  clusterdf$adjustedpvalue <- p.adjust(clusterdf$pvalues, method = "fdr")

  clusterdf$xlogp <- as.numeric(sapply(clusterdf$name, function(x) {  median(df1$xlogp[which(df1$class==x)]) }))

  clustdf <- clusterdf

  clustdf.e <- clustdf[order(clustdf$pvalues),]
  clustdf.e$pvalues <- signif(clustdf.e$pvalues, digits = 2)
  clustdf.e$adjustedpvalue <- signif(clustdf.e$adjustedpvalue, digits = 2)
  clustdf.e$upratio <- signif(clustdf.e$upratio, digits = 1)
  clustdf.e$altratio <- signif(clustdf.e$altratio, digits = 1)

  clustdf.e <- clustdf.e[,c("name","csize","pvalues","adjustedpvalue","keycpdname","alteredMetabolites","upcount","downcount","upratio","altratio")]

  names(clustdf.e) <- c("Cluster name","Cluster size","p-values","FDR","Key compound","Altered metabolites","Increased","Decreased","Increased ratio","Altered Ratio")

  #XLConnect::createSheet(exc,'ChemRICH_Results')
  #XLConnect::writeWorksheet(exc, clustdf.e, sheet = "ChemRICH_Results", startRow = 1, startCol = 2)


  #write.table(clustdf.e, file="cluster_level_results_altered.txt", col.names = T, row.names = F, quote = F, sep="\t")
  #writeLines(toJSON(clustdf), "clusterJson.json")
  gdf <- datatable(clustdf.e,options = list(pageLength = 10),rownames = F)
  gdf$width  <- "auto"
  gdf$height <- "auto"
  saveWidget(gdf,file="clusterlevel.html",selfcontained = F)

  clusterdf$Compounds <- sapply(clusterdf$name, function(x) {
    dfx <- df1[which(df1$class==x),]
    paste(dfx$Compound.Name,collapse="<br>")
  }) ## this one is the label on the tooltip of the ggplotly plot.

  clustdf <- clusterdf[which(cluster.pvalues!=1),]
  #################################################
  ########## Impact Visualization Graph ###########
  #################################################

  clustdf.alt.impact <- clustdf[which(clustdf$pvalues<0.05 & clustdf$csize>1 & clustdf$alteredMetabolites>1) ,]

  clustdf.alt.impact <- clustdf.alt.impact[order(clustdf.alt.impact$xlogp),]
  clustdf.alt.impact$order <- 1:nrow(clustdf.alt.impact) ### Order is decided by the hclust algorithm.
  clustdf.alt.impact$logPval <- -log(clustdf.alt.impact$pvalues)

  p2 <- ggplot(clustdf.alt.impact,aes(x=xlogp,y=-log(pvalues)))
  p2 <- p2 + geom_point(aes(size=csize, color=upratio)) +
    #labs(subtitle = "Figure Legend : Point size corresponds to the count of metabolites in the group. Point color shows that proportion of the increased metabolites where red means high and blue means low number of upregulated compounds.")+
    scale_color_gradient(low = "blue", high = "red")+
    scale_size(range = c(5, 30)) +
    scale_y_continuous("-log (pvalue)",limits = c(0, max(-log(clustdf.alt.impact$pvalues))+4  )) +
    scale_x_continuous(" median XlogP of clusters ") +
    theme_bw() +
    #labs(title = "ChemRICH cluster impact plot") +
    geom_label_repel(aes(label = name), color = "gray20",family="Arial",data=subset(clustdf.alt.impact, csize>2),force = 5)+
    theme(text=element_text(family="Arial Black"))+
    theme(
      plot.title = element_text(face="bold", size=30,hjust = 0.5),
      axis.title.x = element_text(face="bold", size=20),
      axis.title.y = element_text(face="bold", size=20, angle=90),
      panel.grid.major = element_blank(), # switch off major gridlines
      panel.grid.minor = element_blank(), # switch off minor gridlines
      legend.position = "none", # manually position the legend (numbers being from 0,0 at bottom left of whole plot to 1,1 at top right)
      legend.title = element_blank(), # switch off the legend title
      legend.text = element_text(size=12),
      legend.key.size = unit(1.5, "lines"),
      legend.key = element_blank(), # switch off the rectangle around symbols in the legend
      legend.spacing = unit(.05, "cm"),
      axis.text.x = element_text(size=10,angle = 0, hjust = 1),
      axis.text.y = element_text(size=15,angle = 0, hjust = 1)
    )

  read_pptx() %>%
    add_slide(layout = "Title and Content", master = "Office Theme") %>%
    ph_with_vg(code = print(p2), type = "body", width=10, height=8, offx =0.0 , offy = 0.0) %>%
    print(target = "chemrich_impact_plot.pptx") %>%
    invisible()

  #
  #   wbp <- ReporteRs::pptx(template = system.file("data","chem_rich_temp.pptx", package = "reportTemplates"))
  #   #wbp <- pptx(template = "chem_rich_temp.pptx")
  #   wbp <- ReporteRs::addSlide( wbp, "lipidClust" )
  #   wbp <- ReporteRs::addPlot( wbp,  function() print(p2), offx =0.0 , offy = 0.0, width = 8, height = 6 , vector.graphic = TRUE )
  #   ReporteRs::writeDoc( wbp, file = "chemrich_impact_plot.pptx" )
  ggsave("chemrich_impact_plot.png", p2,height = 8, width = 12, dpi=300)

  #ggsave("tst.png",height=9,width=12,dpi=72)

  ##########################################################
  ##### Interactive Visualization plot using GGPlotLY ######
  ###########################################################

  p2 <- ggplot(clustdf.alt.impact,aes(label=name,label2=pvalues, label3=csize,label4=Compounds))
  p2 <- p2 + geom_point(aes(x=xlogp,y=-log(pvalues),size=csize, color=upratio)) + scale_color_gradient(low = "blue", high = "red")+ scale_size(range = c(5, 30)) +
    #labs(caption = "Figure Legend : Point size corresponds to the count of metabolites in the group. Point color shows that proportion of the increased metabolites where red means high and blue means low number of upregulated compounds.")+
    scale_y_continuous("-log (pvalue)",limits = c(0, max(-log(clustdf.alt.impact$pvalues))+5  )) +
    scale_x_continuous(" median XlogP of clusters ") +
    theme_bw() +
    #labs(title = "ChemRICH cluster impact plot") +
    geom_text(aes(x=xlogp,y=-log(pvalues),label = name), color = "gray20",data=subset(clustdf.alt.impact, csize>2))+
    theme(
      plot.title = element_text(face="bold", size=30,hjust = 0.5),
      axis.title.x = element_text(face="bold", size=20),
      axis.title.y = element_text(face="bold", size=20, angle=90),
      panel.grid.major = element_blank(), # switch off major gridlines
      panel.grid.minor = element_blank(), # switch off minor gridlines
      legend.position = "none", # manually position the legend (numbers being from 0,0 at bottom left of whole plot to 1,1 at top right)
      legend.title = element_blank(), # switch off the legend title
      legend.text = element_text(size=12),
      legend.key.size = unit(1.5, "lines"),
      legend.key = element_blank(), # switch off the rectangle around symbols in the legend
      legend.spacing = unit(.05, "cm"),
      axis.text.x = element_text(size=15,angle = 0, hjust = 1),
      axis.text.y = element_text(size=15,angle = 0, hjust = 1)
    )
  gg <- ggplotly(p2,tooltip = c("label","label2","label4"), width = 1600, height = 1000)
  saveWidget(gg,file = "ggplotly.html", selfcontained = F)

  #################################
  ### Interactive volcano plot  ###
  #################################
  # we need to add the interactive volcano plot for the p-values and fold-change sorted by the MeSH tree order.
  df2 <- df1.order
  df2 <- df2[order(df2$xlogp),]
  df2$Changed <- "No Change"
  df2$Changed[which(df2$pvalue<0.05 & df2$foldchange>1)] <- "UP"
  df2$Changed[which(df2$pvalue<0.05 & df2$foldchange<1)] <- "DOWN"
  df2$Changed <- as.factor(df2$Changed)
  df2$pathway <- "No"
  df2$pathway[which(df2$CID%in%cid_biosys==TRUE)] <- "yes"
  df2$pathway <- as.factor(df2$pathway)
  df2$Compound.Name <- factor(df2$Compound.Name, levels =df2$Compound.Name)
  df2$foldchange <- round(sapply(df2$foldchange, function(x) { if(x>1) {x} else {1/x} }), digits = 1)
  df2$foldchange[ df2$foldchange>5] <- 5

  p2 <-   ggplot(df2, aes(label=Compound.Name,x=Compound.Name, y=-log(pvalue,base = 10),colour = Changed,shape=pathway, size=foldchange)) +  scale_size(range = c(1, 10)) +
    #geom_line(position=pd, size=2)+
    #geom_errorbar(aes(ymin = V2-V3 , ymax=V2+V3), width=.3,size=2,position=pd) +
    geom_point(stat = "identity") + # 21 is filled circle
    #geom_bar(stat="identity", size=.1,position=position_dodge()) +
    scale_y_continuous("pvalue (-log)") +
    scale_x_discrete("Metabolites: Red- increased,blue-decreased,yellow-not significant, solid-pathway(s) found ") +
    scale_color_manual("Student ttest",values=c("blue", "yellow", "red","white")) +
    scale_fill_manual("",values=c("white", "yellow", "red","white")) +
    scale_shape_manual("Pathway found",values=c(1,16))+
    #scale_shape(solid = FALSE) +
    theme_bw() +
    labs(title = "Metabolic Dys-regulations sorted by chemical similarity") +
    theme(
      plot.title = element_text(face="bold", size=30,hjust = 0.5),
      axis.title.x = element_text(face="bold", size=20),
      axis.title.y = element_text(face="bold", size=30, angle=90),
      panel.grid.major = element_blank(), # switch off major gridlines
      panel.grid.minor = element_blank(), # switch off minor gridlines
      #legend.justification=c(1,0),
      #legend.position=c(1,.6),
      legend.position = "none",
      #legend.title = element_blank(), # switch off the legend title
      #legend.text = element_text(size=12),
      #legend.key.size = unit(1.5, "lines"),
      #legend.key = element_blank(), # switch off the rectangle around symbols in the legend
      #legend.spacing = unit(.05, "cm"),
      #axis.text.x = element_text(size=15,angle = 45, hjust = 1.0),
      axis.text.x= element_blank(),
      axis.text.y = element_text(size=15,angle = 0, hjust = 0.5)
    )
  #p2
  p3 <- ggplotly(p2, width = 1600, height = 1000)
  htmlwidgets::saveWidget(p3, "dysregplot.html", selfcontained = F)

  df1$pvalue <- signif(df1$pvalue, digits = 2)
  df1$foldchange <- signif(df1$foldchange, digits = 2)
  df1$FDR <- signif(  p.adjust(df1$pvalue), digits = 2)

  gdf <- datatable(df1,options = list(pageLength = 10), rownames = F)

  gdf$width  <- "auto"
  gdf$height <- "auto"
  saveWidget(gdf,file="compoundlevel.html",selfcontained = F)

  l <- list("ChemRICH_Results" = clustdf.e, "Compound_ChemRICH" = df1 )
  openxlsx::write.xlsx(l, file = "ChemRICH_results.xlsx", asTable = TRUE)

}

